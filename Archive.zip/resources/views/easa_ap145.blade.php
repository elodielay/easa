<!DOCTYPE html>
<html lang="en">

<head>

    <style>
        body {
            background-image: url('/easa/AP145.PNG');
            background-position: center;
            background-size: 842px 595px;
            z-index: 99;
            font-size: 15px;
        }
    </style>
</head>

<body>

    <span style='position :absolute; z-index :9999; top:60px; left :750px;'>{{ $easa->easa_code }}</span>
    <span style='position :absolute; z-index :9999; top :140px;  left :750px; '>{{ $easa->order_code }}</span>


    <table style="position:absolute; z-index:9999; top:225px; left: 60px;">
    @foreach($items as $item)
        <tr>
            <td>{{ $item->item }}</td>
            <td style="padding-left:71px;">{{ $item->description }}</td>
            <td style="padding-left:220px;">{{ $item->product }}</td>
            <td style="padding-left:95px;">{{ $item->quantity}}</td>
            <td style="padding-left:84px;">{{ $item->quantity}}</td>
            <td style="padding-left:70px; ">{{ $item->serial_number }}</td>
            <td style="padding-left:130px; ">{{ $item->eligibility }}</td>
        </tr>
    @endforeach
    </table>

    <span style='position :absolute; z-index :9999; top :290px;  left :80px; '>{{ $easa->comment }}</span>
    <span style='position :absolute; z-index :9999; top :537px;  left :530px; '>{{ $user->nom }} {{ $user->prenom }}</span>
    <span style='position :absolute; z-index :9999; top :537px;  left :770px; '>{{ $easa->date }}</span>

</body>