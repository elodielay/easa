<!DOCTYPE html>
<html lang="en">

<head>

    <style>
        body {
            background-image: url('/easa/FAR145.png');
            background-position: center;
            background-size: 842px 595px;
            z-index: 99;
            font-size: 11px;;
        }
    </style>
</head>

<body>

    <span style='position :absolute; z-index :9999; top:50px; left :820px;'>{{ $easa->easa_code }}</span>
    <span style='position :absolute; z-index :9999; top :150px;  left :820px; '>{{ $easa->order_code }}</span>


    <table style="position:absolute; z-index:9999; top:214px; left: 55px;">
    @foreach($items as $item)
        <tr>
            <td>{{ $item->item }}</td>
            <td style="padding-left:90px;">{{ $item->description }}</td>
            <td style="padding-left:200px;">{{ $item->product }}</td>
            <td style="padding-left:110px;">{{ $item->quantity}}</td>
            <td style="padding-left:85px;">{{ $item->serial_number}}</td>
            <td style="padding-left:170px; ">{{ $item->status }}</td>
        </tr>
    @endforeach
    </table>


    <span style='position :absolute; z-index :9999; top :330px;  left :100px; '>{{ $easa->comment }}</span>
    <span style='position :absolute; z-index :9999; top :510px;  left :520px; '>{{ $user->nom }} {{ $user->prenom }}</span>
    <span style='position :absolute; z-index :9999; top :510px;  left :285px; '>{{ $easa->date }}</span>

</body>