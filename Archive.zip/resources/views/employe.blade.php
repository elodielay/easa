
<style>
    body {
        background-image : url('/easa/img4.jpeg');
        background-repeat: no-repeat;
        background-position: 0 0;
        background-attachment: fixed;
    }

</style>
        
<body>  
    
    @extends('employe_list')
    
    @extends('nav')

</body>
