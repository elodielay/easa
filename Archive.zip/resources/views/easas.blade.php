<style>
    body {
        background-image : url('/easa/img5.jpg');
        background-repeat: no-repeat;
        background-position: 0 0;
        background-attachment: fixed;
    }

</style>
        
<body>  
    
@extends('easas_list')


@extends('nav')

</body>
