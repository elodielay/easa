<!DOCTYPE html>
<html lang="en">

<head>

    <style>
        #form {
            margin: 5px;
            font-size: 11px;
        }

        #all {
            border-style: solid;
            border-width: medium;
            border-color: black;

        }

        #right {
            border-right: solid;
            border-width: medium;
            border-color: black;
        }

        #up {
            border-top: solid;
            border-width: medium;
            border-color: black;
        }
    </style>
</head>

<body>

    <form id="form" class="row text-dark" method="POST" action="/easa/public/index.php/liste_easas/<?php echo e($easa->id); ?>">
        <div id="all" class="container-md">
            <?php echo csrf_field(); ?>
            <div class="row ml-0 mr-0">
                <div id="right" class="col">
                    1. Approving Competent Autority/Country
                    <br>
                    <em>Bon de commande / Contrat / Facture</em>
                    <div class="text-center">
                        DIRECTION GÉNÉRALE DE L'AVATION CIVILE FRANÇAISE
                    </div>
                </div>

                <div id="right" class="col">
                    <div class="text-center">
                        AUTHORISED RELEASE CERTIFICATE
                        <br>
                        Certificat Libératoire Autorisé
                        <br>
                        EASA FORM 1
                        <br>
                        Formulaire 1 de l'EASA
                    </div>
                </div>

                <div class="col pt">
                    3. Form Tracking Number
                    <br>
                    <em>N° de repère du formulaire</em>
                    <br>
                    <p na:e="code_easa"><?php echo e($easa->easa_code); ?></p>
                </div>
            </div>



            <div class="row ml-0 mr-0" id="up">
                <div id="right" class="col">
                    4. Organisation Name and Adress
                    <br>
                    <em>Nom et adresse de l'organisme</em>
                </div>


                <div id="right" class="col">
                    <div class="text-center">
                        <img src="/easa/cobham.png">
                        <br>
                        TEAM trading as Cobham Avionics
                    </div>
                </div>

                <div id="right" class="col">
                    <div class="text-center">
                        TEAM
                        <br>
                        174 Quai de Jemmapes
                        <br>
                        SILIC - BP 20191
                        <br>
                        75010 PARIS CEDEX
                        <br>
                        FRANCE
                    </div>
                </div>

                <div class="col">
                    5. Work order / Contract / Invoice
                    <br>
                    <em>Bon de commande / Contrat / Facture</em>
                    <br><br>
                    <p><?php echo e($easa->order_code); ?></p>
                </div>
            </div>


            <div class="row ml-0 mr-0" id="up">
                <div id="right" class="col">
                    12. Remarks
                    <br>
                    <div class="text-center">Remarques</div>
                </div>

                <div id="right" class="col-4">
                    Amandement :
                    <input type="text" name="amdt" class="form-control mb-2" value="<?php echo e($easa->amdt); ?>" name="amdt">
                </div>

                <div id="right" class="col">
                    N° de livraison :
                    <br><br>
                    <?php echo e($easa->delivery_code); ?>

                </div>


                <div class="col">
                    Client :
                    <br><br>
                    <?php echo e($easa->code_client); ?>

                </div>

                <div class="col mt-4">
                    <input type="text" class="form-control mb-2" name="code_client">
                </div>


            </div>



            <div class="row ml-0 mr-0" id="up">
                <textarea class="form-control m-2" name="remarque"><?php echo e($easa->comment); ?></textarea>


            </div>
            <div class="row ml-0 mr-0" id="up">
                <div id="right" class="col">
                    14a. Certifies that the items identified above were manufactured in conformity to :
                    <br>
                    <em>Certifie que les éléments identifiés ci-dessus ont été fabriqués conformement aux :</em>
                    <br><br>

                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="choix1">
                        <label class="form-check-label" for="choix1">
                            approved design data and are in condition for sale operation
                            <br><em>données de conception approuvées et sont en état de fonctionner en toute sécurité</em>
                        </label>
                    </div>

                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="choix2">
                        <label class="form-check-label" for="choix2">
                            non-approved design data specified in block 12
                            <br><em>données de conception non approuvées spécifiées dans la case 12</em>
                        </label>
                    </div>
                </div>

                <div class="col mt-2">
                    14a.
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="1">
                        <label class="form-check-label" for="1">
                            Part-145 A 50 Release to Service
                            <br><em>Approbation pour remise en service
                                <br>Selon Partie 145 A 50</em>
                        </label>
                    </div>

                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="2">
                        <label class="form-check-label" for="2">
                            Other regulation specified in block 12
                            <br><em>Autre régulation précisée en case 12
                        </label>
                    </div>

                    <br><br>
                    Certifies that unless otherwise specified in block 12, the work identified in block 12 and described in block 12, was accomplished in accordance
                    with Part-145 and in respect to that work the items are considered ready for the release to service.
                    <br>
                    Certifie que, sauf indicatio contraire spécifiée en case 12, les travaux identifiés en case 12 et décrits en case 12 ont été réalisés conformément
                    à la partie 145 et qu'au vu de ces travaux, les pièces sont considérées prêtes à la rentrée en service.
                </div>
            </div>


            <div class="row ml-0 mr-0" id="up">
                <div id="right" class="col">
                    14b. Authorised signature
                    <br><em>Signature autorisée</em>
                </div>

                <div id="right" class="col">
                    14c. Approval /Authorisation Number
                    <br><em>Numéro d'agrément / d'autorisation</em>
                </div>

                <div id="right" class="col">
                    14b. Authorised signature :
                    <br><em>Signature autorisée</em>
                </div>

                <div class="col mt-3">
                    14c. Approval /Authorisation Number :
                    <br><em>Numéro d'agrément / d'autorisation</em>
                </div>
            </div>

            <?php if(!session('user_defined')): ?>
                <div class="row ml-0 mr-0" id="up">

                    <div id="right" class="col">
                        14d. Name / Nom :
                        <br>
                        <input id="name" list="browsers" name="name" >
                        <datalist id="browsers">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option><?php echo e($user->nom); ?> <?php echo e($user->prenom); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </datalist>
                    </div>

                    <div id="right" class="col">
                        14e. Date(d/m/y) / Date(j/m/a) :
                        <input id="date" name="date" type="date" class="form-control mb-1" name="date" value="<?php echo e($easa->date); ?>">
                    </div>



                    <div id="right" class="col">
                        14d. Name / Nom :
                        <br>
                        <input id="nameBis" list="browsers" name="name">
                        <datalist id="browsers">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option><?php echo e($user->nom); ?> <?php echo e($user->prenom); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </datalist>
                    </div>



                    <div class="col">
                        14e. Date(d/m/y) / Date(j/m/a) :
                        <input id="dateBis" type="date" class="form-control mb-1" name="date" value="<?php echo e($easa->date); ?>">
                    </div>
                </div>
            <?php endif; ?>


            <?php if(session('user_defined')): ?>
                <div class="row ml-0 mr-0" id="up">

                    <div id="right" class="col">
                        14d. Name / Nom :
                        <br>
                        <input id="name" list="browsers" name="name" value="<?php echo e($userFiche->nom); ?> <?php echo e($userFiche->prenom); ?>">
                        <datalist id="browsers">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option><?php echo e($user->nom); ?> <?php echo e($user->prenom); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </datalist>
                    </div>

                    <div id="right" class="col">
                        14e. Date(d/m/y) / Date(j/m/a) :
                        <input id="date" name="date" type="date" class="form-control mb-1" name="date" value="<?php echo e($easa->date); ?>">
                    </div>



                    <div id="right" class="col">
                        14d. Name / Nom :
                        <br>
                        <input id="nameBis" list="browsers" name="name" value="<?php echo e($userFiche->nom); ?> <?php echo e($userFiche->prenom); ?>">
                        <datalist id="browsers">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option><?php echo e($user->nom); ?> <?php echo e($user->prenom); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </datalist>
                    </div>



                    <div class="col">
                        14e. Date(d/m/y) / Date(j/m/a) :
                        <input id="dateBis" type="date" class="form-control mb-1" name="date" value="<?php echo e($easa->date); ?>">
                    </div>
                </div>

            <?php endif; ?>

           




            <script>
                var name = document.getElementById("name");
                var date = document.getElementById("date");

                var nameBis = document.getElementById("nameBis");
                var dateBis = document.getElementById("dateBis");

                $("#name").keyup(function() {
                    nameBis.value = this.value;
                });

                $("#nameBis").keyup(function() {
                    name.value = this.value;
                });

                $("#date").keyup(function() {
                    dateBis.value = this.value;
                });

                $("#dateBis").keyup(function() {
                    date.value = this.value;
                });
            </script>



            <div class="row ml-0 mr-0" id="up">
                <div id="right" class="col">
                    <textarea class="form-control m-2" name="observation"><?php echo e($easa->observation); ?></textarea>
                </div>

                <div class="col">
                    Document Liberatoire imprimé, numerisé et validé
                </div>
            </div>

        </div>

        <?php if(!session('creation') && !session('update')): ?>
        <button id="submit" type="submit" class="btn btn-success btn-sm mt-2">OK</button>
        <?php endif; ?>


    </form>


    <div id="all" class="container-md">
        <div class="row ml-0 mr-0 mt-3">
            <div class="col">
                <ul class="list-group list-group-flush text-dark">
                    <li class="list-group-item">
                        <div class="row">
                            <p class="col">Item</p>

                            <p class="col">Description</p>

                            <p class="col">N° Article</p>

                            <p class="col">Quantité</p>

                            <p class="col">N° de série</p>

                            <p class="col">Etat</p>


                            <?php if(!session('creation')): ?>
                            <a href="/easa/public/index.php/liste_easas/<?php echo e($easa->id); ?>/item/create">
                                <svg class="bi bi-plus-square ml-1" width="10" height="10" viewBox="0 0 16 16" fill="black" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" d="M8 3.5a.5.5 0 01.5.5v4a.5.5 0 01-.5.5H4a.5.5 0 010-1h3.5V4a.5.5 0 01.5-.5z" clip-rule="evenodd" />
                                    <path fill-rule="evenodd" d="M7.5 8a.5.5 0 01.5-.5h4a.5.5 0 010 1H8.5V12a.5.5 0 01-1 0V8z" clip-rule="evenodd" />
                                    <path fill-rule="evenodd" d="M14 1H2a1 1 0 00-1 1v12a1 1 0 001 1h12a1 1 0 001-1V2a1 1 0 00-1-1zM2 0a2 2 0 00-2 2v12a2 2 0 002 2h12a2 2 0 002-2V2a2 2 0 00-2-2H2z" clip-rule="evenodd" />
                                </svg>
                            </a>

                            <?php endif; ?>

                            <?php if(session('creation')): ?>
                            <a href="/easa/public/index.php/liste_easas/<?php echo e($easa->id); ?>">
                                <svg class="bi bi-x-square" width="10" height="10" viewBox="0 0 16 16" fill="red" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" d="M14 1H2a1 1 0 00-1 1v12a1 1 0 001 1h12a1 1 0 001-1V2a1 1 0 00-1-1zM2 0a2 2 0 00-2 2v12a2 2 0 002 2h12a2 2 0 002-2V2a2 2 0 00-2-2H2z" clip-rule="evenodd" />
                                    <path fill-rule="evenodd" d="M11.854 4.146a.5.5 0 010 .708l-7 7a.5.5 0 01-.708-.708l7-7a.5.5 0 01.708 0z" clip-rule="evenodd" />
                                    <path fill-rule="evenodd" d="M4.146 4.146a.5.5 0 000 .708l7 7a.5.5 0 00.708-.708l-7-7a.5.5 0 00-.708 0z" clip-rule="evenodd" />
                                </svg>

                            </a>

                            <?php endif; ?>
                        </div>
                    </li>

                    <?php if(session('creation')): ?>
                    <li class="list-group-item">
                        <form method="POST" action="/easa/public/index.php/liste_easas/<?php echo e($easa->id); ?>/item/create">
                            <?php echo csrf_field(); ?>
                            <div class="form-row">
                                <div class="col">
                                    <input type="text" class="form-control" name="item">
                                </div>

                                <div class="col">
                                    <input type="text" class="form-control" name="description">
                                </div>

                                <div class="col">
                                    <input type="text" class="form-control" name="product">
                                </div>

                                <div class="col">
                                    <input type="number" class="form-control" name="quantity">
                                </div>

                                <div class="col">
                                    <input type="text" class="form-control" name="serial_number">
                                </div>

                                <div class="col">
                                    <input type="text" class="form-control" name="status">
                                </div>

                                <input type="submit" value="Submit">

                            </div>
                        </form>


                    </li>
                    <?php endif; ?>


                    <?php if(session('update')): ?>
                    <li class="list-group-item">
                        <form action="/easa/public/index.php/liste_easas/<?php echo e($itemUpdate->easa_id); ?>/item/<?php echo e($itemUpdate->id); ?>/update" method="POST">

                            <div class="form-row">
                                <?php echo csrf_field(); ?>
                                <div class="col">
                                    <input type="text" class="form-control" value="<?php echo e($itemUpdate->item); ?>" name="item" required>
                                </div>

                                <div class="col">
                                    <input type="text" class="form-control" value="<?php echo e($itemUpdate->description); ?>" name="description" required>
                                </div>

                                <div class="col">
                                    <input type="text" class="form-control" value="<?php echo e($itemUpdate->product); ?>" name="product" required>
                                </div>

                                <div class="col">
                                    <input type="number" class="form-control" value="<?php echo e($itemUpdate->quantity); ?>" name="quantity" required>
                                </div>

                                <div class="col">
                                    <input type="text" class="form-control" value="<?php echo e($itemUpdate->serial_number); ?>" name="serial_number" required>
                                </div>

                                <div class="col">
                                    <input type="text" class="form-control" value="<?php echo e($itemUpdate->status); ?>" name="status" required>
                                </div>

                                <button class="btn btn-link" type="submit">
                                    <svg class="bi bi-check-box" width="25" height="25" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" d="M15.354 2.646a.5.5 0 010 .708l-7 7a.5.5 0 01-.708 0l-3-3a.5.5 0 11.708-.708L8 9.293l6.646-6.647a.5.5 0 01.708 0z" clip-rule="evenodd" />
                                        <path fill-rule="evenodd" d="M1.5 13A1.5 1.5 0 003 14.5h10a1.5 1.5 0 001.5-1.5V8a.5.5 0 00-1 0v5a.5.5 0 01-.5.5H3a.5.5 0 01-.5-.5V3a.5.5 0 01.5-.5h8a.5.5 0 000-1H3A1.5 1.5 0 001.5 3v10z" clip-rule="evenodd" />
                                    </svg>
                                </button>


                            </div>


                        </form>

                    </li>
                    <?php endif; ?>

                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">
                        
                        <div class="row">

                            <p class="col"><?php echo e($item->item); ?></p>

                            <p class="col"><?php echo e($item->description); ?></p>

                            <p class="col"><?php echo e($item->product); ?></p>

                            <p class="col"><?php echo e($item->quantity); ?></p>

                            <p class="col"><?php echo e($item->serial_number); ?></p>

                            <p class="col"><?php echo e($item->status); ?></p>

                            <?php if(!session('update')): ?>
                            <a href="/easa/public/index.php/liste_easas/<?php echo e($item->easa_id); ?>/item/<?php echo e($item->id); ?>/update">

                                <svg class="bi bi-pencil-square" width="10" height="10" viewBox="0 0 16 16" fill="blue" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M15.502 1.94a.5.5 0 010 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 01.707 0l1.293 1.293zm-1.75 2.456l-2-2L4.939 9.21a.5.5 0 00-.121.196l-.805 2.414a.25.25 0 00.316.316l2.414-.805a.5.5 0 00.196-.12l6.813-6.814z" />
                                    <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 002.5 15h11a1.5 1.5 0 001.5-1.5v-6a.5.5 0 00-1 0v6a.5.5 0 01-.5.5h-11a.5.5 0 01-.5-.5v-11a.5.5 0 01.5-.5H9a.5.5 0 000-1H2.5A1.5 1.5 0 001 2.5v11z" clip-rule="evenodd" />
                                </svg>

                            </a>

                            <a href="/easa/public/index.php/liste_easas/<?php echo e($item->easa_id); ?>/item/<?php echo e($item->id); ?>/del">
                                <svg class="bi bi-trash ml-1" width="10" height="10" viewBox="0 0 16 16" fill="red" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M5.5 5.5A.5.5 0 016 6v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm2.5 0a.5.5 0 01.5.5v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm3 .5a.5.5 0 00-1 0v6a.5.5 0 001 0V6z" />
                                    <path fill-rule="evenodd" d="M14.5 3a1 1 0 01-1 1H13v9a2 2 0 01-2 2H5a2 2 0 01-2-2V4h-.5a1 1 0 01-1-1V2a1 1 0 011-1H6a1 1 0 011-1h2a1 1 0 011 1h3.5a1 1 0 011 1v1zM4.118 4L4 4.059V13a1 1 0 001 1h6a1 1 0 001-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z" clip-rule="evenodd" />
                                </svg>
                            </a>

                            <?php endif; ?>


                            <?php if(session('update')): ?>
                            <a href="/easa/public/index.php/liste_easas/<?php echo e($item->easa_id); ?>">
                                <svg class="bi bi-x-square" width="10" height="10" viewBox="0 0 16 16" fill="red" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" d="M14 1H2a1 1 0 00-1 1v12a1 1 0 001 1h12a1 1 0 001-1V2a1 1 0 00-1-1zM2 0a2 2 0 00-2 2v12a2 2 0 002 2h12a2 2 0 002-2V2a2 2 0 00-2-2H2z" clip-rule="evenodd" />
                                    <path fill-rule="evenodd" d="M11.854 4.146a.5.5 0 010 .708l-7 7a.5.5 0 01-.708-.708l7-7a.5.5 0 01.708 0z" clip-rule="evenodd" />
                                    <path fill-rule="evenodd" d="M4.146 4.146a.5.5 0 000 .708l7 7a.5.5 0 00.708-.708l-7-7a.5.5 0 00-.708 0z" clip-rule="evenodd" />
                                </svg>
                            </a>

                            <?php endif; ?>
                        </div>

                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                </ul>
            </div>

        </div>
    </div>


    <a href="/easa/public/index.php/liste_easas"><button type="button" class="btn btn-danger mt-2 btn-sm">Fermer</button></a>

    <?php if(session('pdf')): ?>
    <a href="/easa/public/index.php/liste_easas/<?php echo e($easa->id); ?>/pdf">
        <svg class="bi bi-file-earmark-plus mt-2" width="30" height="30" viewBox="0 0 16 16" fill="black" xmlns="http://www.w3.org/2000/svg">
            <path d="M9 1H4a2 2 0 00-2 2v10a2 2 0 002 2h5v-1H4a1 1 0 01-1-1V3a1 1 0 011-1h5v2.5A1.5 1.5 0 0010.5 6H13v2h1V6L9 1z" />
            <path fill-rule="evenodd" d="M13.5 10a.5.5 0 01.5.5v2a.5.5 0 01-.5.5h-2a.5.5 0 010-1H13v-1.5a.5.5 0 01.5-.5z" clip-rule="evenodd" />
            <path fill-rule="evenodd" d="M13 12.5a.5.5 0 01.5-.5h2a.5.5 0 010 1H14v1.5a.5.5 0 01-1 0v-2z" clip-rule="evenodd" />
        </svg>
    </a>

    <?php endif; ?>

</body<?php /**PATH /Users/layelodie/Sites/easa/resources/views/easa_fiche.blade.php ENDPATH**/ ?>