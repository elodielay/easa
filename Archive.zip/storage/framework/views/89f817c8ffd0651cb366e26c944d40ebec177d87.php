<style>
    body {
        background-image : url('/easa/img5.jpg');
        background-repeat: no-repeat;
        background-position: 0 0;
        background-attachment: fixed;
    }

</style>
        
<body>  
    





</body>

<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('easas_list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/layelodie/Sites/easa/resources/views/easas.blade.php ENDPATH**/ ?>