<!DOCTYPE html>
<html lang="en">

<head>

    <style>
        body {
            background-image: url('/easa/JAR21.png');
            background-position: center;
            background-size: 842px 595px;
            z-index: 99;
        }
    </style>
</head>

<body>

    <span style='position :absolute; z-index :9999; top:50px; left :820px;'><?php echo e($easa->easa_code); ?></span>
    <span style='position :absolute; z-index :9999; top :150px;  left :820px; '><?php echo e($easa->order_code); ?></span>


    <table style="position:absolute; z-index:9999; top:200px; left: 60px;">
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->item); ?></td>
            <td style="padding-left:90px;"><?php echo e($item->description); ?></td>
            <td style="padding-left:200px;"><?php echo e($item->product); ?></td>
            <td style="padding-left:110px;"><?php echo e($item->quantity); ?></td>
            <td style="padding-left:85px;"><?php echo e($item->serial_number); ?></td>
            <td style="padding-left:170px; "><?php echo e($item->status); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <span style='position :absolute; z-index :9999; top :330px;  left :100px; '><?php echo e($easa->comment); ?></span>
    <span style='position :absolute; z-index :9999; top :510px;  left :70px; '><?php echo e($user->nom); ?> <?php echo e($user->prenom); ?></span>
    <span style='position :absolute; z-index :9999; top :510px;  left :285px; '><?php echo e($easa->date); ?></span>

</body><?php /**PATH /Users/layelodie/Sites/easa/resources/views/easa_jar21.blade.php ENDPATH**/ ?>