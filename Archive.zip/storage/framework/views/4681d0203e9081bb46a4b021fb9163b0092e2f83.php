<div class="col mt-2">
    <div class="jumbotron bg-white">

        <div class="row">
            <div class="col mr-5">
                <h2 class="text-dark">Liste des easas</h2>
            </div>


            <form class="col ml-5" action="/easa/public/index.php/liste_easas/recherche" method="GET">
                <input type="text" placeholder="Recherchez" name="recherche">
                <button type="submit">OK</button>
            </form>
        </div>

        <ul class="list-group list-group-flush text-dark">

            <li class="list-group-item">
                <div class="row">
                    <h6 class="col">Code Easa</h6>

                    <h6 class="col">Type</h6>

                    <h6 class="col"> Code Client </h6>

                    <h6 class="col">Code Commande</h6>

                    <h6 class="col">N° Livraison</h6>

                    <h6 class="col">Approuvé</h6>

                    <h6 class="col">Validé</h6>


                    <a href="#">
                        <svg class="bi bi-trash ml-2" width="15" height="15" viewBox="0 0 16 16" fill="white" xmlns="http://www.w3.org/2000/svg">
                            <path d="M5.5 5.5A.5.5 0 016 6v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm2.5 0a.5.5 0 01.5.5v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm3 .5a.5.5 0 00-1 0v6a.5.5 0 001 0V6z" />
                            <path fill-rule="evenodd" d="M14.5 3a1 1 0 01-1 1H13v9a2 2 0 01-2 2H5a2 2 0 01-2-2V4h-.5a1 1 0 01-1-1V2a1 1 0 011-1H6a1 1 0 011-1h2a1 1 0 011 1h3.5a1 1 0 011 1v1zM4.118 4L4 4.059V13a1 1 0 001 1h6a1 1 0 001-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z" clip-rule="evenodd" />
                        </svg>
                    </a>
                </div>
            </li>

            <li class="list-group-item">
                <?php if(session('creation')): ?>
                <form class="row text-dark font-weight-bold" method="POST" action="/easa/public/index.php/liste_easas">
                    <div class="form-row">
                        <?php echo csrf_field(); ?>
                        <div class="col">
                            <input type="text" class="form-control" name="code_easa" required>
                        </div>

                        <div class="col">
                            <select class="custom-select" name="type" required>
                                <option selected disabled value="">Type</option>
                                <option>FAR145</option>
                                <option>JAR21</option>
                                <option>JAR145</option>
                                <option>CCAR145</option>
                                <option>TCCA145</option>
                                <option>AP145</option>
                            </select>
                        </div>

                        <div class="col">
                            <input type="text" class="form-control" name="code_client" required>
                        </div>

                        <div class="col">
                            <input type="text" class="form-control" name="code_commande" required>
                        </div>

                        <div class="col">
                            <input type="text" class="form-control" name="num_livraison" required>
                        </div>

                        <div class="col">
                            <select class="custom-select" name="approved" required>
                                <option selected disabled value="">...</option>
                                <option>Oui</option>


                                <option>Non</option>
                            </select>
                        </div>

                        <div class="col">
                            <select class="custom-select" name="valid" required>
                                <option selected disabled value="">...</option>
                                <option>Oui</option>
                                <option>Non</option>
                            </select>
                        </div>

                        <button class="btn btn-link" type="submit">
                            <svg class="bi bi-check-box" width="25" height="25" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" d="M15.354 2.646a.5.5 0 010 .708l-7 7a.5.5 0 01-.708 0l-3-3a.5.5 0 11.708-.708L8 9.293l6.646-6.647a.5.5 0 01.708 0z" clip-rule="evenodd" />
                                <path fill-rule="evenodd" d="M1.5 13A1.5 1.5 0 003 14.5h10a1.5 1.5 0 001.5-1.5V8a.5.5 0 00-1 0v5a.5.5 0 01-.5.5H3a.5.5 0 01-.5-.5V3a.5.5 0 01.5-.5h8a.5.5 0 000-1H3A1.5 1.5 0 001.5 3v10z" clip-rule="evenodd" />
                            </svg>
                        </button>

                    </div>
                </form>
                <?php endif; ?>


                <?php if(session('update')): ?>
                <form class="row text-dark font-weight-bold" method="POST" action="/easa/public/index.php/liste_easas/<?php echo e($easa->id); ?>/update">
                    <div class="form-row">
                        <?php echo csrf_field(); ?>
                        <div class="col">
                            <input type="text" class="form-control" value="<?php echo e($easa->easa_code); ?>" name="code_easa" required>
                        </div>

                        <div class="col">
                            <select class="custom-select" name="type" required>

                                <option <?php echo e($easa->type=='FAR145'?'selected':null); ?>>FAR145</option>
                                <option <?php echo e($easa->type=='JAR21'?'selected':null); ?>>JAR21</option>
                                <option <?php echo e($easa->type=='JAR145'?'selected':null); ?>>JAR145</option>
                                <option <?php echo e($easa->type=='CCAR145'?'selected':null); ?>>CCAR145</option>
                                <option <?php echo e($easa->type=='TCCA145'?'selected':null); ?>>TCCA145</option>
                                <option <?php echo e($easa->type=='AP145'?'selected':null); ?>>AP145</option>

                            </select>
                        </div>

                        <div class="col">
                            <input type="text" class="form-control" value="<?php echo e($easa->code_client); ?>" name="code_client" required>
                        </div>

                        <div class="col">
                            <input type="text" class="form-control" value="<?php echo e($easa->order_code); ?>" name="code_commande" required>
                        </div>

                        <div class="col">
                            <input type="text" class="form-control" value="<?php echo e($easa->delivery_code); ?>" name="num_livraison" required>
                        </div>

                        <div class="col">
                            <select class="custom-select" name="approved" required>
                                <option <?php echo e($easa->approved=='Oui'?'selected':null); ?>>Oui</option>
                                <option <?php echo e($easa->approved=='Non'?'selected':null); ?>>Non</option>
                            </select>
                        </div>

                        <div class="col">
                            <select class="custom-select" name="valid" required>
                                <option <?php echo e($easa->valid=='Oui'?'selected':null); ?>>Oui</option>
                                <option <?php echo e($easa->valid=='Non'?'selected':null); ?>>Non</option>
                            </select>
                        </div>

                        <button class="btn btn-link" type="submit">
                            <svg class="bi bi-check-box" width="25" height="25" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" d="M15.354 2.646a.5.5 0 010 .708l-7 7a.5.5 0 01-.708 0l-3-3a.5.5 0 11.708-.708L8 9.293l6.646-6.647a.5.5 0 01.708 0z" clip-rule="evenodd" />
                                <path fill-rule="evenodd" d="M1.5 13A1.5 1.5 0 003 14.5h10a1.5 1.5 0 001.5-1.5V8a.5.5 0 00-1 0v5a.5.5 0 01-.5.5H3a.5.5 0 01-.5-.5V3a.5.5 0 01.5-.5h8a.5.5 0 000-1H3A1.5 1.5 0 001.5 3v10z" clip-rule="evenodd" />
                            </svg>
                        </button>

                    </div>
                </form>
                <?php endif; ?>

            </li>


            <?php $__currentLoopData = $easas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $easa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            <li class="list-group-item">

                <div class="row">

                    <h6 class="col"><?php echo e($easa->easa_code); ?></h6>

                    <h6 class="col ml-5"><?php echo e($easa->type); ?></h6>

                    <h6 class="col ml-5"><?php echo e($easa->code_client); ?></h6>

                    <h6 class="col ml-5"><?php echo e($easa->order_code); ?></h6>

                    <h6 class="col ml-5"><?php echo e($easa->delivery_code); ?></h6>

                    <h6 class="col ml-5"><?php echo e($easa->approved); ?></h6>

                    <h6 class="col ml-5"><?php echo e($easa->valid); ?></h6>


                    <?php if(session('creation')): ?>
                    <a href="/easa/public/index.php/liste_easas/<?php echo e($easa->id); ?>/update">

                        <svg class="bi bi-pencil-square" width="13" height="13" viewBox="0 0 16 16" fill="blue" xmlns="http://www.w3.org/2000/svg">
                            <path d="M15.502 1.94a.5.5 0 010 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 01.707 0l1.293 1.293zm-1.75 2.456l-2-2L4.939 9.21a.5.5 0 00-.121.196l-.805 2.414a.25.25 0 00.316.316l2.414-.805a.5.5 0 00.196-.12l6.813-6.814z" />
                            <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 002.5 15h11a1.5 1.5 0 001.5-1.5v-6a.5.5 0 00-1 0v6a.5.5 0 01-.5.5h-11a.5.5 0 01-.5-.5v-11a.5.5 0 01.5-.5H9a.5.5 0 000-1H2.5A1.5 1.5 0 001 2.5v11z" clip-rule="evenodd" />
                        </svg>

                    </a>

                    <a href="/easa/public/index.php/liste_easas/<?php echo e($easa->id); ?>/del">
                        <svg class="bi bi-trash ml-1" width="13" height="13" viewBox="0 0 16 16" fill="red" xmlns="http://www.w3.org/2000/svg">
                            <path d="M5.5 5.5A.5.5 0 016 6v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm2.5 0a.5.5 0 01.5.5v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm3 .5a.5.5 0 00-1 0v6a.5.5 0 001 0V6z" />
                            <path fill-rule="evenodd" d="M14.5 3a1 1 0 01-1 1H13v9a2 2 0 01-2 2H5a2 2 0 01-2-2V4h-.5a1 1 0 01-1-1V2a1 1 0 011-1H6a1 1 0 011-1h2a1 1 0 011 1h3.5a1 1 0 011 1v1zM4.118 4L4 4.059V13a1 1 0 001 1h6a1 1 0 001-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z" clip-rule="evenodd" />
                        </svg>
                    </a>

                    <a href="/easa/public/index.php/liste_easas/<?php echo e($easa->id); ?>">
                        <svg class="bi bi-plus-square ml-1" width="13" height="13" viewBox="0 0 16 16" fill="black" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M8 3.5a.5.5 0 01.5.5v4a.5.5 0 01-.5.5H4a.5.5 0 010-1h3.5V4a.5.5 0 01.5-.5z" clip-rule="evenodd" />
                            <path fill-rule="evenodd" d="M7.5 8a.5.5 0 01.5-.5h4a.5.5 0 010 1H8.5V12a.5.5 0 01-1 0V8z" clip-rule="evenodd" />
                            <path fill-rule="evenodd" d="M14 1H2a1 1 0 00-1 1v12a1 1 0 001 1h12a1 1 0 001-1V2a1 1 0 00-1-1zM2 0a2 2 0 00-2 2v12a2 2 0 002 2h12a2 2 0 002-2V2a2 2 0 00-2-2H2z" clip-rule="evenodd" />
                        </svg>
                    </a>

                    <a href="/easa/public/index.php/liste_easas/<?php echo e($easa->id); ?>/dupliquer">
                        <svg class="bi bi-file-plus ml-1" width="13" height="13" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9 1H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V8h-1v5a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1h5V1z" />
                            <path fill-rule="evenodd" d="M13.5 1a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1H13V1.5a.5.5 0 0 1 .5-.5z" />
                            <path fill-rule="evenodd" d="M13 3.5a.5.5 0 0 1 .5-.5h2a.5.5 0 0 1 0 1H14v1.5a.5.5 0 0 1-1 0v-2z" />
                        </svg>
                    </a>

                    <?php endif; ?>

                    <?php if(session('update')): ?>
                    <a href="/easa/public/index.php/liste_easas">

                        <svg class="bi bi-x-square ml-1" width="15" height="15" viewBox="0 0 16 16" fill="red" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M14 1H2a1 1 0 00-1 1v12a1 1 0 001 1h12a1 1 0 001-1V2a1 1 0 00-1-1zM2 0a2 2 0 00-2 2v12a2 2 0 002 2h12a2 2 0 002-2V2a2 2 0 00-2-2H2z" clip-rule="evenodd" />
                            <path fill-rule="evenodd" d="M11.854 4.146a.5.5 0 010 .708l-7 7a.5.5 0 01-.708-.708l7-7a.5.5 0 01.708 0z" clip-rule="evenodd" />
                            <path fill-rule="evenodd" d="M4.146 4.146a.5.5 0 000 .708l7 7a.5.5 0 00.708-.708l-7-7a.5.5 0 00-.708 0z" clip-rule="evenodd" />
                        </svg>

                    </a>

                    <?php endif; ?>
                </div>

            </li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <br>

        <?php echo e($easas->links()); ?>

    </div>



</div>
</div>
</div><?php /**PATH /Users/layelodie/Sites/easa/resources/views/easas_list.blade.php ENDPATH**/ ?>