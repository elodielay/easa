        <div class="col">        
            <div class="text-center d-inline">
                <title>Register</title>   
            </div>

            <form class="needs-validation" novalidate>
                <div class="form-row">

                    <div class="col-md-4 mb-3 mx-auto">
                        <label for="validationTooltip01">Name</label>
                        <input type="text" class="form-control" id="name" placeholder="First name" required>
                        <div class="valid-tooltip">
                            Looks good!
                        </div>
                    </div>
                </div>

                <div class="form-row">
                    <div class="col-md-4 mb-3 mx-auto">
                        <label for="validationTooltip02">Last Name</label>
                        <input type="text" class="form-control" id="lastname" placeholder="Last name" required>
                        <div class="valid-tooltip">
                            Looks good!
                        </div>
                    </div>
                </div>
 
                

                <div class="form-row">
                    <div class="col-md-4 mb-3 mx-auto">
                        <label for="validationTooltip02">Email</label>
                        <input type="email" class="form-control" id="email" placeholder="Email" required>
                        <div class="valid-tooltip">
                            Looks good!
                        </div>
                    </div>
                </div>

                <div class="form-row">
                    <div class="col-md-4 mb-3 mx-auto">
                        <label for="validationTooltip02">Password</label>
                        <input type="password" class="form-control" id="password" required>
                        <div class="valid-tooltip">
                            Looks good!
                        </div>
                    </div>
                </div>
 
                <div class="text-center">
                    <button class="btn btn-primary" type="submit">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>


<?php /**PATH /Users/layelodie/Sites/easa/resources/views/create.blade.php ENDPATH**/ ?>