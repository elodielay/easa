
        <?php if(session('login')): ?>
            <div class="col-md-5 offset-md-2 pb-3 pl-4 pr-4 align-self-center center-block"> 
                <div class="jumbotron bg-white">
                    <h2 class="text-dark">Bienvenue !</h2>
                    <p class="lead text-dark"><?php echo e(session('login')); ?></p>
                    <hr class="my-4">
                    <p class="lead">
                        <a class="btn btn-primary btn-lg" href="http://localhost/easa/public/index.php/modifier" role="button">Liste des employés</a>
                        <a class="btn btn-primary btn-lg" href="http://localhost/easa/public/index.php/del" role="button">Déconnexion</a>
                    </p>
            </div>
        <?php endif; ?>
               
        
        </div>

    </div>
</div>
<?php /**PATH /Users/layelodie/Sites/easa/resources/views/homeadmin.blade.php ENDPATH**/ ?>