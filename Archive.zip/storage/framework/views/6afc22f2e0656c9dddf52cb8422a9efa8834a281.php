<div class="col mt-2">
    <div class="jumbotron bg-white">
        <div class="row">
            <div class="col mr-5">
                <h2 class="text-dark">Liste des employés</h2>
            </div>


        </div>


   

        <ul class="list-group list-group-flush text-dark">

            <?php if(session('update')): ?>
            <li class="list-group-item">
                <div class="row">
                    <h6 class="col">Nom</h6>

                    <h6 class="col">Prénom</h6>

                    <h6 class="col">Email</h6>

                    <h6 class="col">Rôle</h6>

                    <h6 class="col">MDP actuel</h6>

                    <h6 class="col">Nouveau MDP</h6>


                    <a href="#">
                        <svg class="bi bi-trash ml-2" width="15" height="15" viewBox="0 0 16 16" fill="white" xmlns="http://www.w3.org/2000/svg">
                            <path d="M5.5 5.5A.5.5 0 016 6v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm2.5 0a.5.5 0 01.5.5v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm3 .5a.5.5 0 00-1 0v6a.5.5 0 001 0V6z" />
                            <path fill-rule="evenodd" d="M14.5 3a1 1 0 01-1 1H13v9a2 2 0 01-2 2H5a2 2 0 01-2-2V4h-.5a1 1 0 01-1-1V2a1 1 0 011-1H6a1 1 0 011-1h2a1 1 0 011 1h3.5a1 1 0 011 1v1zM4.118 4L4 4.059V13a1 1 0 001 1h6a1 1 0 001-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z" clip-rule="evenodd" />
                        </svg>
                    </a>

                </div>

                <form class="row text-dark font-weight-bold" method="POST" action="/easa/public/index.php/liste_employes/<?php echo e($userSelec->id); ?>/update">
                    <div class="form-row">
                        <?php echo csrf_field(); ?>
                        <div class="col">
                            <input type="text" class="form-control" value="<?php echo e($userSelec->nom); ?>" name="name" required>
                        </div>

                        <div class="col">
                            <input type="text" class="form-control" value="<?php echo e($userSelec->prenom); ?>" name="lastname" required>
                        </div>

                        <div class="col">
                            <input type="email" class="form-control" value="<?php echo e($userSelec->email); ?>" name="email" required>
                        </div>

                        <div class="col">
                            <input type="text" class="form-control" value="<?php echo e($userSelec->role); ?>" name="role" required>
                        </div>

                        <div class="col">
                            <input type="password" class="form-control" name="oldpassword">
                        </div>

                        <?php if(session('ok')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong><?php echo e(session('ok')); ?></strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <?php endif; ?>

                        <div class="col">
                            <input type="password" class="form-control" name="newpassword">
                        </div>

                        <button class="btn btn-link" type="submit">
                            <svg class="bi bi-check-box" width="25" height="25" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" d="M15.354 2.646a.5.5 0 010 .708l-7 7a.5.5 0 01-.708 0l-3-3a.5.5 0 11.708-.708L8 9.293l6.646-6.647a.5.5 0 01.708 0z" clip-rule="evenodd" />
                                <path fill-rule="evenodd" d="M1.5 13A1.5 1.5 0 003 14.5h10a1.5 1.5 0 001.5-1.5V8a.5.5 0 00-1 0v5a.5.5 0 01-.5.5H3a.5.5 0 01-.5-.5V3a.5.5 0 01.5-.5h8a.5.5 0 000-1H3A1.5 1.5 0 001.5 3v10z" clip-rule="evenodd" />
                            </svg>
                        </button>

                    </div>
                </form>

            </li>
            <?php endif; ?>



            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            <li class="list-group-item">
                <div class="row">
                    <h6 class="col"><?php echo e($user->nom); ?> <?php echo e($user->prenom); ?></h6>
                    

                    <?php if(!session('update')): ?>

                    <a href="/easa/public/index.php/liste_employes/<?php echo e($user->id); ?>/update">
                        <svg class="bi bi-pencil-square float-right" width="20" height="20" viewBox="0 0 16 16" fill="blue" xmlns="http://www.w3.org/2000/svg">
                            <path d="M15.502 1.94a.5.5 0 010 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 01.707 0l1.293 1.293zm-1.75 2.456l-2-2L4.939 9.21a.5.5 0 00-.121.196l-.805 2.414a.25.25 0 00.316.316l2.414-.805a.5.5 0 00.196-.12l6.813-6.814z" />
                            <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 002.5 15h11a1.5 1.5 0 001.5-1.5v-6a.5.5 0 00-1 0v6a.5.5 0 01-.5.5h-11a.5.5 0 01-.5-.5v-11a.5.5 0 01.5-.5H9a.5.5 0 000-1H2.5A1.5 1.5 0 001 2.5v11z" clip-rule="evenodd" />
                        </svg>

                    </a>

                    <a href="/easa/public/index.php/liste_employes/<?php echo e($user->id); ?>/del">
                        <svg class="bi bi-trash float-right mr-3" width="20" height="20" viewBox="0 0 16 16" fill="red" xmlns="http://www.w3.org/2000/svg">
                            <path d="M5.5 5.5A.5.5 0 016 6v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm2.5 0a.5.5 0 01.5.5v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm3 .5a.5.5 0 00-1 0v6a.5.5 0 001 0V6z" />
                            <path fill-rule="evenodd" d="M14.5 3a1 1 0 01-1 1H13v9a2 2 0 01-2 2H5a2 2 0 01-2-2V4h-.5a1 1 0 01-1-1V2a1 1 0 011-1H6a1 1 0 011-1h2a1 1 0 011 1h3.5a1 1 0 011 1v1zM4.118 4L4 4.059V13a1 1 0 001 1h6a1 1 0 001-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z" clip-rule="evenodd" />
                        </svg>
                    </a>

                    <?php endif; ?>

                    <?php if(session('update')): ?>
                    <a href="/easa/public/index.php/liste_employes">
                        <svg class="bi bi-x-square" width="15" height="15" viewBox="0 0 16 16" fill="red" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M14 1H2a1 1 0 00-1 1v12a1 1 0 001 1h12a1 1 0 001-1V2a1 1 0 00-1-1zM2 0a2 2 0 00-2 2v12a2 2 0 002 2h12a2 2 0 002-2V2a2 2 0 00-2-2H2z" clip-rule="evenodd" />
                            <path fill-rule="evenodd" d="M11.854 4.146a.5.5 0 010 .708l-7 7a.5.5 0 01-.708-.708l7-7a.5.5 0 01.708 0z" clip-rule="evenodd" />
                            <path fill-rule="evenodd" d="M4.146 4.146a.5.5 0 000 .708l7 7a.5.5 0 00.708-.708l-7-7a.5.5 0 00-.708 0z" clip-rule="evenodd" />
                        </svg>

                    </a>

                    <?php endif; ?>
                </div>

            </li>





            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

    <?php echo e($users->links()); ?>


</div>
</div>
</div><?php /**PATH /Users/layelodie/Sites/easa/resources/views/employe_list.blade.php ENDPATH**/ ?>