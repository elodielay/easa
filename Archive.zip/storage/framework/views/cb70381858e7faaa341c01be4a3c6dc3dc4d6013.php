<style>
    body {
        background-image : url('/easa/img3.jpeg');
        background-repeat: no-repeat;
        background-position: 0 0;
        background-attachment: fixed;
    }

</style>
        
<body>  
    
    
    

</body>

<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('login_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/layelodie/Sites/easa/resources/views/login.blade.php ENDPATH**/ ?>