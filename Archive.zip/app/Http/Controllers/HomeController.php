<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use App\User;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Auth;

class HomeController extends Controller
{

    public function show(Request $request)
    {   
        return view('home');
    }

    public function logout(Request $request)
    {
        $request->session()->forget('login');
        $request->session()->forget('connecte');
        $request->session()->forget('admin');
        return view('home');
    }
}
