<?php

namespace App\Http\Controllers;


use Illuminate\Routing\Controller as BaseController;
use Illuminate\Http\Request;
use App\User;
use App\Easa;
use App\Item;

class ListItems extends Controller
{

    public function showInsertItem(Request $request, $id)
    {
        $easa = Easa::find($id);
        $users = User::all();
        $items = Item::where('easa_id', $id)->get();
        $userFiche = User::where('id', $easa->user_hab_id)->first();
        $request->session()->put('creation', 'hello');  
        $request->session()->forget('update');
        return view('easa',compact('easa', 'users', 'items', 'userFiche') );
    }


    public function showItemUpdate(Request $request, $id, $id2)
    {
        $easa = Easa::find($id);
        $users = User::all();
        $items = Item::where('easa_id', $id)->get();
        $userFiche = User::where('id', $easa->user_hab_id)->first();
        $itemUpdate = Item::find($id2);

        $request->session()->put('update', 'hello');  
        $request->session()->forget('creation');
        return view('easa',compact('easa', 'users', 'items', 'itemUpdate', 'userFiche') );
    
    }


    public function insertItem(Request $request, $id)
    {

        $idend = strval($id); 
        $link = 'liste_easas/'.$idend;

        $item = new Item();

        $item->easa_id = $id;
        $item->item = $request->item;
        $item->description = $request->description;
        $item->product = $request->product;
        $item->status = $request->status;
        $item->quantity = $request->quantity;
        $item->serial_number = $request->serial_number;
        
        $item->save();

        return redirect($link);
    }

    public function updateItem(Request $request, $id, $id2)
    {

        $item = Item::find($id2);

        $idend = strval($id);
        $link = 'liste_easas/'.$idend;

        $item->easa_id = $id;
        $item->item = $request->item;
        $item->description = $request->description;
        $item->status = "";
        $item->product = $request->product;
        $item->eligibility = $request->eligibility;
        $item->quantity = $request->quantity;
        $item->serial_number = $request->serial_number;
        
            
        $item->save();


        return redirect($link);
    
    }

    public function del(Request $request, $id, $id2)
    {

        $item = Item::find($id2);
        $item->delete();

        $idend = strval($id);
        $link = 'liste_easas/'.$idend;

        return redirect($link);
    }


}
