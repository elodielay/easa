<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Easa;
use App\Item;
use Barryvdh\DomPDF\Facade;


class ListEasas extends Controller
{

    public function show(Request $request)
    {
        $request->session()->put('creation', 'hello');  
        $request->session()->forget('update');
        $easas = Easa::all(); 
        $users = User::all();
        return view('easas', ["easas" => $easas], ["users"=>$users],);
    }

    public function showFormUpdate(Request $request, $id)
    {
        $easaUpdate = Easa::find($id);
        $easas = Easa::all();
        $request->session()->forget('creation');
        $request->session()->put('update', $id); 
        

        return view('easas', ["easas" => $easas], ["easa" => $easaUpdate]);
    }

    public function showFiche(Request $request, $id)
    {
        $request->session()->forget('creation');
        $request->session()->forget('update');
        $request->session()->forget('user_defined');
        $request->session()->forget('user_not_defined');
    
        $easa = Easa::find($id);
        $items = Item::where('easa_id', $id)->get();
        $userFiche = User::firstWhere('id', $easa->user_hab_id);
        $users = User::all();

        if($userFiche != null){
            $request->session()->put('user_defined', $userFiche); 
            return view('easa',compact('easa', 'users', 'items', 'userFiche'));
        }

        else if($userFiche == null) return view('easa',compact('easa', 'users', 'items'));
        
        
    }


    public function insert(Request $request)
    {

        $easa = new Easa();

        $easa->easa_code = $request->code_easa;
        $easa->type = $request->type;
        $easa->code_client = $request->code_client;
        $easa->order_code = $request->code_commande;
        $easa->delivery_code = $request->num_livraison;
        $easa->approved = $request->approved;
        $easa->valid = $request->valid;

        $easa->save();


        return redirect('liste_easas');
    }


    public function update(Request $request, $id)
    {

        $easa = Easa::find($id);

        
        $easa->easa_code = $request->code_easa;
        $easa->type = $request->type;
        $easa->code_client = $request->code_client;
        $easa->order_code = $request->code_commande;
        $easa->delivery_code = $request->num_livraison;
        $easa->approved = $request->approved;
        $easa->valid = $request->valid;
            
        $easa->save();


        return redirect('liste_easas');
    
    }

    public function updateFiche(Request $request, $id)
    {

      
       
            $easa = Easa::find($id);

        
            $easa->easa_code = $easa->easa_code;
            $easa->type = $easa->type;
            $easa->code_client = $easa->code_client;
            $easa->order_code = $easa->order_code;
            $easa->delivery_code = $easa->delivery_code;
            $easa->approved =  $easa->approved;
            $easa->valid = $easa->valid;
    
            $name = explode(" ", $request->name);
            

            $user = User::where([ ['prenom', $name[1]] , ['nom', $name[0]] ])->first();

            $id = $user->id;
            $easa->user_hab_id = $id;
            $easa->date = $request->date;
            $easa->comment = $request->remarque;
            $easa->amdt = $request->amdt;
            $easa->observation = $request->observation;
          
                
            $easa->save();
            $request->session()->put('pdf', 'Générer le PDF'); 
    
            return redirect()->back();
        
    }


    public function del(Request $request, $id)
    {

        $easa = Easa::find($id);
        $easa->delete();

        return redirect('liste_easas');
    }

    public function createPDF(Request $request, $id)
    {

        // Fetch all customers from database
        $easa = Easa::find($id);
        $items = Item::where('easa_id', $id)->get();
        $user = User::where('id', $easa->user_hab_id)->first();

        // Send data to the view using loadView function of PDF facade

        if($easa->type == 'JAR21')
            $pdf = Facade::loadView('easa_jar21', compact('easa', 'items', 'user'));

        else if($easa->type == 'FAR145')
            $pdf = Facade::loadView('easa_far145', compact('easa', 'items', 'user'));

        else if($easa->type == 'JAR145')
            $pdf = Facade::loadView('easa_jar145', compact('easa', 'items', 'user'));

        else if($easa->type == 'CCAR145')
            $pdf = Facade::loadView('easa_ccar145', compact('easa', 'items', 'user'));

        else if($easa->type == 'TCCA145')
            $pdf = Facade::loadView('easa_tcca145', compact('easa', 'items', 'user'));

        else if($easa->type == 'AP145')
            $pdf = Facade::loadView('easa_ap145', compact('easa', 'items', 'user'));

        $pdf->setPaper('a4','landscape');

        // If you want to store the generated pdf to the server then you can use the store function
        $pdf->save(storage_path().'easa.pdf');

        // Finally, you can download the file using download function
        return $pdf->download('easa.pdf');
        
    }







    
}
