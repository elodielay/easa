<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use App\User;
use Illuminate\Support\Facades\Hash;

class RegisterController extends BaseController
{
    use AuthorizesRequests, 
    DispatchesJobs, 
    ValidatesRequests;

    public function show(){
        return view('register');
    }



    public function insert(Request $request){

        $user = new User();
 
        $user->nom = $request->name;
        $user->prenom = $request->lastname;
        $user->email = $request->email;

        if($request->password == $request->confirmpassword){
            $user->password = Hash::make($request->password);
        }

        else return redirect()->back()->with('error','Mot de passe ne correspond pas');
        
        $user->role = 'ici';
        $user->save();

        
        return redirect('.');

    }
}
