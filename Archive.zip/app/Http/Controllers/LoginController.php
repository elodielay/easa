<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use App\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class LoginController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function show(){
        return view('login');
    }

    
    public function check(Request $request){

        $user = User::firstWhere('email', $request->email); //check si l'email existe dans la bd

        if($user != null) {

            if (Hash::check($request->password, $user->password )) { //check si le mdp de l'user trouvé match celui tapé 

                $admin = 'admin';
                $request->session()->put('connecte', 'hello'); 

                if($user->role == $admin )  { 
                   $request->session()->put('admin', 'Liste des employés');  
                    
                }
                
                else{ 
                    $request->session()->put('login', 'Connexion réussi'); 
                }
                
                $request->session()->put('nom',$user->nom);
                $request->session()->put('prenom',$user->prenom);
                $request->session()->put('id',$user->id);
                
                return redirect('.'); // connection réussi
            }

            return redirect('login')->with('error','Mot de passe incorrect !');
        }

        else return redirect('login')->with('error',"Votre compte n'existe pas ! ");
       
    }
}


