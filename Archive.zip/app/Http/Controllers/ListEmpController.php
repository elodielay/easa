<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use App\User;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Auth;

class ListEmpController extends Controller
{

    public function show(Request $request)
    {
        $users = User::all();
        $users = User::paginate(10);
        $request->session()->forget('update');

        return view('employe', ["users"=>$users]);
    }

    public function showForm(Request $request, $id)
    {
        $user = User::find($id);
        $users = User::all();
        $users = User::paginate(10);
        $request->session()->put('update', 'hello');  
        return view('employe', ["userSelec"=>$user], ["users"=>$users]);
    }

    

    public function update(Request $request, $id)
    {

        $user = User::find($id);

        
        $user->nom = $request->name;
        $user->prenom = $request->lastname;
        $user->email = $request->email;
        $user->role = $request->role;
            
        $user->save();

        if($request->oldpassword != null && $request->newpassword != null){
            if(Hash::check($request->oldpassword, $user->password )) {
                $user->password = Hash::make($request->newpassword);
                $user->save();
            }
            
            else 
                return redirect()->back()->with("ok", "Mot de passe erroné ! Veillez réessayer.");
        }

        return redirect('liste_employes')->with("ok", "Changement reussie ! ");
    
    }

    public function del(Request $request, $id)
    {

        $user = User::find($id); 
        $user->delete();

        return redirect('liste_employes');
    
    }


    
}
