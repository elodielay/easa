<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//HOME
Route::get('/', 'HomeController@show');
Route::get('/del', 'HomeController@logout');


//LISTE DES EMPLOYÉS
Route::get('/liste_employes', 'ListEmpController@show');
Route::get('/liste_employes/{id}/update', 'ListEmpController@showForm');
Route::post('/liste_employes/{id}/update', 'ListEmpController@update');


//LISTE DES EASAS
Route::get('/liste_easas', 'ListEasas@show');
Route::get('/liste_easas/{id}/update', 'ListEasas@showFormUpdate');
Route::post('/liste_easas/{id}/update', 'ListEasas@update');
Route::get('/liste_easas/{id}/del', 'ListEasas@del');
Route::post('/liste_easas', 'ListEasas@insert');
Route::get('/liste_easas/{id}/dupliquer', 'ListEasas@duplicate');
Route::get('/liste_easas/recherche', 'ListEasas@search');


//FICHE EASA DETAILS
Route::get('/liste_easas/{id}', 'ListEasas@showFiche');
Route::post('/liste_easas/{id}', 'ListEasas@updateFiche');
Route::get('/liste_easas/{id}/pdf','ListEasas@createPDF');

// LISTE DES ITEMS
Route::get('/liste_easas/{id}/item/create', 'ListItems@showInsertItem');
Route::post('/liste_easas/{id}/item/create', 'ListItems@insertItem');
Route::get('/liste_easas/{id}/item/{id2}/update', 'ListItems@showItemUpdate');
Route::post('/liste_easas/{id}/item/{id2}/update', 'ListItems@updateItem');
Route::get('/liste_easas/{id}/item/{id2}/del', 'ListItems@del');



//REGISTER
Route::get('/register', 'RegisterController@show');
Route::post('/register', 'RegisterController@insert');


//LOGIN
Route::get('/login', 'LoginController@show');
Route::post('/login', 'LoginController@check');