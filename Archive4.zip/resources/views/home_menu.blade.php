
        @if (session('login'))
            <div class="col-md-5 offset-md-2 pb-3 pl-4 pr-4 align-self-center center-block"> 
                <div class="jumbotron bg-white">
                    <h2 class="text-dark">Bienvenue {{ session('prenom') }} {{ session('nom') }} </h2>
                    <p class="lead text-dark">{{ session('login') }}</p>
                    <hr class="my-4">
                    <p class="lead">
                        <a class="btn btn-primary btn-lg" href="/easa/public/index.php/liste_easas" role="button">EASAS</a>
                        <a class="btn btn-primary btn-lg" href="del" role="button">Déconnexion</a>
                    </p>
            </div>
        @endif


        @if (session('admin'))
            <div class="col-md-5 offset-md-2 pb-3 pl-4 pr-4 align-self-center center-block"> 
                <div class="jumbotron bg-white">
                    <h2 class="text-dark">Bienvenue {{ session('prenom') }} {{ session('nom') }} </h2>
                    <p class="lead text-dark">{{ session('login') }}</p>
                    <hr class="my-4">
                    <p class="lead">
                        <a class="btn btn-primary btn-lg" href="/easa/public/index.php/liste_employes" role="button">{{ session('admin') }}</a>
                        <a class="btn btn-primary btn-lg" href="/easa/public/index.php/liste_easas" role="button">EASAS</a>
                        <a class="btn btn-primary btn-lg" href="/easa/public/index.php/del" role="button">Déconnexion</a>
                    </p>
            </div>
        @endif
               
        
        </div>

    </div>
</div>
