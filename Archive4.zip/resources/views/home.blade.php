<style>
    body {
        background-image : url('/easa/img2.jpeg');
    }

</style>
        
<body>  

    @extends('home_menu');

    @extends('nav')



</body>



