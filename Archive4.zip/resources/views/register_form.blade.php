
        
        <body>   
            <div class="col-md-5 offset-md-2 pb-3 pl-4 pr-4 align-self-center center-block">        
                <div class="shadow-lg p-2 bg-white">
                    <div class="text-center">
                        <svg class="bi bi-person-bounding-box center" width="25" height="25" viewBox="0 0 16 16" fill="black" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M1.5 1a.5.5 0 00-.5.5v3a.5.5 0 01-1 0v-3A1.5 1.5 0 011.5 0h3a.5.5 0 010 1h-3zM11 .5a.5.5 0 01.5-.5h3A1.5 1.5 0 0116 1.5v3a.5.5 0 01-1 0v-3a.5.5 0 00-.5-.5h-3a.5.5 0 01-.5-.5zM.5 11a.5.5 0 01.5.5v3a.5.5 0 00.5.5h3a.5.5 0 010 1h-3A1.5 1.5 0 010 14.5v-3a.5.5 0 01.5-.5zm15 0a.5.5 0 01.5.5v3a1.5 1.5 0 01-1.5 1.5h-3a.5.5 0 010-1h3a.5.5 0 00.5-.5v-3a.5.5 0 01.5-.5z" clip-rule="evenodd"/>
                            <path fill-rule="evenodd" d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd"/>
                        </svg>  
                    </div>

                    <div class="text-center d-inline text-dark">
                        <h1>Créer un compte</h1>   
                    </div>

                    <br>

                    {{ csrf_field() }}

                    <form class="text-dark font-weight-bold" method="POST" action="register">
                        @csrf
                        <div class="form-row">

                            <div class="col mb-3 mx-auto">
                                <label for="name">Nom*</label>
                                <input type="text" class="form-control" name="name" required>
                        
                            </div>
                        </div>

                        

                        <div class="form-row">
                            <div class="col mb-3 mx-auto">
                                <label for="validationTooltip02">Prénom*</label>
                                <input type="text" class="form-control" name="lastname" required>
        
                            </div>
                        </div>
        
                        

                        <div class="form-row">
                            <div class="col mb-3 mx-auto">
                                <label for="validationTooltip02">Email*</label>
                                <input type="email" class="form-control" name="email" required>
                
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="col mb-4 mx-auto">
                                <label for="validationTooltip02">Mot de passe*</label>
                                <input type="password" class="form-control" name="password" required>

                            </div>
                        </div>

                        <div class="form-row">
                            <div class="col mb-4 mx-auto">
                                <label for="validationTooltip02">Confirmer mot de passe*</label>
                                <input type="password" class="form-control" name="confirmpassword" required>

                            </div>
                        </div>

                        @if (session('error'))
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <strong>{{ session('error') }}</strong>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endif

        
                        <div class="text-center">

                    
                            <button class="btn btn-primary pr-5 pl-5" type="submit"> 
                                <svg class="bi bi-check" width="15" height="15" viewBox="0 0 16 16" fill="white" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" d="M13.854 3.646a.5.5 0 010 .708l-7 7a.5.5 0 01-.708 0l-3.5-3.5a.5.5 0 11.708-.708L6.5 10.293l6.646-6.647a.5.5 0 01.708 0z" clip-rule="evenodd"/>
                                </svg>
                                Enregistrer
                            </button>

                            <br><br>
                            
                        </div>

                        <div class="text-danger">
                            * Champ obligatoire
                        </div>

                        
                    </form>

                    
                </div>
            </div>
        </body>
    </div>
</div>


