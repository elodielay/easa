




<style>
    body {
        background-image : url('/easa/img1.jpeg');
        background-repeat: no-repeat;
        background-position: 0 0;
        background-attachment: fixed;
    }

</style>
        
<body>  
    
@extends('register_form')


@extends('nav')

</body>
