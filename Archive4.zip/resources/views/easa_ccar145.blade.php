<!DOCTYPE html>
<html lang="en">

<head>

    <style>
        body {
            background-image: url('/easa/CCAR145.jpg');
            background-position: center;
            background-size: 842px 595px;
            z-index: 99;
            font-size: 14px;
        }
    </style>
</head>

<body>

    <span style='position :absolute; z-index :9999; top:50px; left :820px;'>{{ $easa->easa_code }}</span>
    <span style='position :absolute; z-index :9999; top :150px;  left :820px; '>{{ $easa->order_code }}</span>


    <table style="position:absolute; z-index:9999; top:250px; left: 30px;">
    @foreach($items as $item)
        <tr>
            <td>{{ $item->item }}</td>
            <td style="padding-left:65px;">{{ $item->description }}</td>
            <td style="padding-left:200px;">{{ $item->product }}</td>
            <td style="padding-left:140px;">{{ $item->quantity}}</td>
            <td style="padding-left:140px;">{{ $item->eligibility}}</td>
            <td style="padding-left:50px;">{{ $item->serial_number}}</td>
            <td style="padding-left:90px; ">{{ $item->status }}</td>
        </tr>
    @endforeach
    </table>

    <span style='position :absolute; z-index :9999; top :395px;  left :60px; '>{{ $easa->comment }}</span>
    <span style='position :absolute; z-index :9999; top :613px;  left :130px; '>{{ $user->nom }} {{ $user->prenom }}</span>
    <span style='position :absolute; z-index :9999; top :575px;  left :285px; '>{{ $easa->date }}</span>

</body>