<style>
    body {
        background-image : url('/easa/img2.jpeg');
    }

</style>
        
<body>  

    ;

    



</body>




<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('home_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/layelodie/Sites/easa/resources/views/home.blade.php ENDPATH**/ ?>